from pkg_resources import get_distribution

__version__ = get_distribution('phhelper').version
__release_date__ = "11-mar-2020"

# coding: utf-8
import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name='phhelper',
    version='0.7',
    author='Luiz Henrique Gomes',
    author_email="lhgnet@gmail.com",
    description='Python Handler Helper for Lambda',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/lhgomes/phhelper",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    license='MIT',
)